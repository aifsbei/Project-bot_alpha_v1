while True:
    None if input()[0] in {'а', 'А'} else exit(0)