letters = input()
list_of_letters = letters.split('р')
print(len(sorted(list_of_letters)[-1]))