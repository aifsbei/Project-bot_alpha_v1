string = input()
while len(string) > 2:
    print(string)
    string = string[1:-1]